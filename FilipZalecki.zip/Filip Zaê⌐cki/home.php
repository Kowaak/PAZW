<?php
session_start();
//Jeśli użytkownik nie jest zalogowany, przekieruj do logowania
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.php');
	exit;
}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Strona główna</title>
		<link href="styl.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
	<body class="loggedin">
		<nav class="navtop">
			<div>
				<h1>Forum</h1>
				<a href="utpost.php"><i class="fas fa-newspaper"></i>Utwórz post</a>
				<a href="baza.sql" download><i class="fas fa-file"></i>BazaSQL</a>
				<a href="doku.html"><i class="fas fa-book"></i>Dokumentacja</a>
				<a href="profile.php"><i class="fas fa-user-circle"></i><?=$_SESSION['name']?></a>
				<a href="wylog.php"><i class="fas fa-sign-out-alt"></i>Wyloguj</a>
			</div>
		</nav>
		<div class="content">
			<h1>Posty</h1>
			<?php
			$db = mysqli_connect('localhost','root','','forum2');
			$wynik = mysqli_query($db, "SELECT tytul,tresc,id_uzytkownika,id_postu FROM post");
			$wiersz = mysqli_fetch_all($wynik, MYSQLI_ASSOC);
			foreach ($wiersz as $x) {
				echo "<article><h2><a href='post.php?id={$x['id_postu']}'>{$x['tytul']}</a></h2>";
				echo "Treść:<br>{$x['tresc']}";
				echo "<br><br>Autor:{$x['id_uzytkownika']}</article>";
			}
			?>
		</div>
	</body>
</html>