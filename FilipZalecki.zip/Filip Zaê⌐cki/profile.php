<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.php');
	exit;
}
    $con = mysqli_connect('localhost', 'root', '', 'forum2');
if (mysqli_connect_errno()) {
	exit('Nie udało połączyć się z bazą danych: ' . mysqli_connect_error());
}
$stmt = $con->prepare('SELECT haslo, email FROM konta WHERE id = ?');
$stmt->bind_param('i', $_SESSION['id']);
$stmt->execute();
$stmt->bind_result($password, $email);
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Profil</title>
		<link href="styl.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
	</head>
	<body class="loggedin">
		<nav class="navtop">
			<div>
				<h1>Profil</h1>
				<a href="baza.sql" download><i class="fas fa-file"></i>BazaSQL</a>
				<a href="doku.html"><i class="fas fa-book"></i>Dokumentacja</a>
				<a href="home.php"><i class="fas fa-home"></i>Powrót</a>
				<a href="wylog.php"><i class="fas fa-sign-out-alt"></i>Wyloguj</a>
			</div>
		</nav>
		<div class="content">
			<h2>Detale twojego konta:</h2>
			<div>
				<table>
					<tr>
						<td>Nazwa użytkownika:</td>
						<td><?=$_SESSION['name']?></td>
					</tr>
					<tr>
						<td>Hasło:</td>
						<td><?=$password?></td>
					</tr>
					<tr>
						<td>Email:</td>
						<td><?=$email?></td>
					</tr>
				</table>
			</div>
		</div>
	</body>
</html>