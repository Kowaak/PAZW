<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Utwórz posta</title>
		<link href="styl.css" rel="stylesheet" type="text/css">
    </head>
    <body class="loggedin">
        <div class="content"><p style="font-size: 20px;">
        Ważne jest dla nas Twoje bezpieczeństwo i prywatność. Dlatego też chcielibyśmy poinformować Cię o sposobach, w jakie gromadzimy, używamy i chronimy Twoje dane osobowe. Niniejsza polityka prywatności ma zastosowanie do wszystkich informacji, które podajesz nam w trakcie korzystania z naszych usług.<br><br>
        Gromadzenie danych osobowych: Możemy gromadzić różne rodzaje danych osobowych od Ciebie, takie jak adres e-mail itp. Zebrane dane są wykorzystywane w celu świadczenia usług, komunikacji z Tobą oraz dostosowania naszych ofert do Twoich preferencji.<br><br>
        Używanie danych osobowych: Dane osobowe mogą być wykorzystywane w następujących celach:<br><br>
        Realizacja usług: Twoje dane osobowe mogą być używane do świadczenia usług, z których korzystasz.<br><br>
        Komunikacja: Możemy używać Twoich danych osobowych do kontaktowania się z Tobą w.<br><br>
        celach informacyjnych lub związanych z obsługą klienta.<br><br>
        Ochrona danych osobowych: Stosujemy odpowiednie środki bezpieczeństwa, takie jak szyfrowanie danych i ochrony hasłami, aby chronić Twoje dane osobowe przed nieuprawnionym dostępem, utratą lub nieuprawnionym ujawnieniem.<br><br>
        Pliki cookie: Nasza strona internetowa może używać plików cookie, które są niewielkimi plikami tekstowymi przechowywanymi na Twoim urządzeniu. Pliki cookie pomagają nam dostosować treści i reklamy, analizować sposób korzystania z naszej strony i poprawiać jej funkcjonalność.<br><br>
        Prawa autorskie: Wszystko na tej stronie (z wyjątkiem zdjęcia w tle) jest chronione przez prawa autorskie.
        Jeśli zmienisz zdanie w sprawie udzielonej wcześniej zgody na wykorzystanie swoich danych osobowych, masz prawo skontaktować się z nami i zaktualizować swoje preferencje lub poprosić o usunięcie swoich danych z naszych systemów.<br><br>
        Pamiętaj, że polityka prywatności może ulec zmianie w dowolnym momencie.<br><br>
        <a href="rejestracja.php" style="color:#F194F2">Powrót</a>
        </p>
        </div>
    </body>
</html>