<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rejestracja</title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
	<link href="styl.css" rel="stylesheet" type="text/css">
</head>
	<body class="loggedin">
		<div class="register">
			<h1>Rejestracja</h1>
			<form method="post" autocomplete="off">
				<label for="username">
					<i class="fas fa-user"></i>
				</label>
				<input type="text" name="nick" placeholder="Podaj nazwę użytkownika" id="nick" required>
		    	<label for="password">
					<i class="fas fa-lock"></i>
				</label>
				<input type="password" name="haslo" placeholder="Podaj hasło" id="haslo" required>
				<label for="email">
					<i class="fas fa-envelope"></i>
				</label>
				<input type="email" name="email" placeholder="Podaj email" id="email" required>
				Masz już konto?<a href="index.php">Zaloguj się</a>
				Tworząc konto zgadzasz się n<a href="polit.php">a politykę prywatności</a>
				<input type="submit" value="Zarejestruj">
			</form>
		</div>
	</body>
</html>

<?php
function rej(){
	//Połączenie z bazą danych
    $con = mysqli_connect('localhost','root','','forum2');
		//Walidacja
        if (mysqli_connect_errno()){
            exit("<p style='color:white;text-align:center;'>Błąd: " . mysqli_connect_error()."</p>");
        }
		//Walidacja
        if (!isset($_POST['nick'], $_POST['haslo'], $_POST['email'])){
            exit("<p style='color:white;text-align:center;'>Prosze ukończyć formularz!</p>");
        }
		//Walidacja
        if (strlen($_POST['haslo']) > 20 || strlen($_POST['haslo']) < 5) {
            exit("<p style='color:white;text-align:center;'>Hasło musi mieć miedzy 5 a 20 znaków!</p>");
        }else{
			//Sprawdzenie czy jest już użytkownik o takiej nawzwie
            if ($stmt = $con->prepare('SELECT id, haslo FROM konta WHERE nick = ?')) {
	        $stmt->bind_param('s', $_POST['nick']);
	        $stmt->execute();
	        $stmt->store_result();
	        if ($stmt->num_rows > 0) {
	        	echo "<p style='color:white;text-align:center;'>Nazwa użytkownika jest zajęta, wybierz inną!</p>";
	        } else {
				//Wprowadzenie użytkonownika do bazy
                if ($stmt = $con->prepare('INSERT INTO konta (nick, haslo, email) VALUES (?, ?, ?)')) {
                	// Szyfrowanie hasła
                	$password = password_hash($_POST['haslo'], PASSWORD_DEFAULT);
                	$stmt->bind_param('sss', $_POST['nick'], $password, $_POST['email']);
                	$stmt->execute();
                	header('Location: index.php');
            } else {
            	echo "<p style='color:white;text-align:center;'>Błąd z bazą danych</p>";
                }
            	    }
            	$stmt->close();
            } else {
            	echo "<p style='color:white;text-align:center;'>Błąd z bazą danych</p>";
                }
            }
            $con->close();
		}
		 //Sprawdzenie czy formularz jest pusty, jeśli nie uruchomienie funkcji logowania
			if (!empty($_POST['nick']) || !empty($_POST['haslo']) || !empty($_POST['email'])){
				rej();
			}else{
				echo "<p style='color:white;text-align:center;'>Prosze wypełnić formularz</p>";
			}
?>