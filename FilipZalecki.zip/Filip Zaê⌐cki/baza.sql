-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 22 Maj 2023, 18:30
-- Wersja serwera: 10.4.25-MariaDB
-- Wersja PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `forum2`
--
CREATE DATABASE IF NOT EXISTS `forum2` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `forum2`;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `kome`
--

CREATE TABLE `kome` (
  `id_kom` int(11) NOT NULL,
  `id_us` int(11) DEFAULT NULL,
  `id_post` int(11) DEFAULT NULL,
  `tresc` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `kome`
--

INSERT INTO `kome` (`id_kom`, `id_us`, `id_post`, `tresc`) VALUES
(1, 1, 1, 'ASYGDUAIFGDSUADSFGUASYGDF'),
(4, 7, 1, 'asdasd'),
(27, 7, 1, 'asdasd');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `konta`
--

CREATE TABLE `konta` (
  `id` int(11) NOT NULL,
  `nick` varchar(20) NOT NULL,
  `haslo` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `konta`
--

INSERT INTO `konta` (`id`, `nick`, `haslo`, `email`) VALUES
(1, 'kOWAAK', '$2y$10$ZPzVCixuCmAFjLb/4AOfiOBXWnwdsVl8DNl9gk6xAcl567cMAkyri', 'aaaa@aa'),
(2, 'asdasd', '$2y$10$bNPFQulj/NRcqeL2WRJYB.ilt4WareVdDosvmkCcthoRCI3i3wkjq', '123@123'),
(3, 'Kowaak2', '$2y$10$nh1pN6ub8hgU4RPWu9St.ujuK1jd.VDmrsPl09lDMhP6UuMIlUC66', 'a@d'),
(4, 'Kowaak123', '$2y$10$HB9RCQelvRGm7TiAuAv6reFMgRuvhSan25B4dk/EXbQbcRfPa.cRe', '1@d'),
(5, 'Kowaak123123', '$2y$10$PDTx2Kxsx84mnAy0tqkDWOMCBCCbVPoNR1m59iRojhT2TNy8adUj.', '1@1'),
(6, 'asd', '$2y$10$d5CnslRxJrYGVZ0ikPCBAug67r1pnmWwo.sXGJ025zujzwcPsX80W', 'a@a'),
(7, 'asdasdasd', '$2y$10$obwXFtD/JgVn/4yOxx95AugylKIB05b7GnPDgnaCU66bhLkIXL8lq', 'a@a');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `post`
--

CREATE TABLE `post` (
  `id_postu` int(11) NOT NULL,
  `tytul` varchar(50) DEFAULT NULL,
  `tresc` varchar(200) DEFAULT NULL,
  `id_uzytkownika` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `post`
--

INSERT INTO `post` (`id_postu`, `tytul`, `tresc`, `id_uzytkownika`) VALUES
(1, 'AADSADSADSASD', 'DFSAEADSFDFSGDFSDSFGDFGHFGHHNG', 1),
(6, '123', '123', 1),
(7, 'asdasd', 'asd', 1),
(8, 'tYTUL TEST', 'asdasdasd', 6),
(9, 'tYTUL TEST', 'assdsd', 7);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `kome`
--
ALTER TABLE `kome`
  ADD PRIMARY KEY (`id_kom`),
  ADD KEY `id_us` (`id_us`),
  ADD KEY `id_post` (`id_post`);

--
-- Indeksy dla tabeli `konta`
--
ALTER TABLE `konta`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id_postu`),
  ADD KEY `id_uzytkownika` (`id_uzytkownika`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `kome`
--
ALTER TABLE `kome`
  MODIFY `id_kom` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT dla tabeli `konta`
--
ALTER TABLE `konta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT dla tabeli `post`
--
ALTER TABLE `post`
  MODIFY `id_postu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `kome`
--
ALTER TABLE `kome`
  ADD CONSTRAINT `kome_ibfk_1` FOREIGN KEY (`id_us`) REFERENCES `konta` (`id`),
  ADD CONSTRAINT `kome_ibfk_2` FOREIGN KEY (`id_post`) REFERENCES `post` (`id_postu`);

--
-- Ograniczenia dla tabeli `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `post_ibfk_1` FOREIGN KEY (`id_uzytkownika`) REFERENCES `konta` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
