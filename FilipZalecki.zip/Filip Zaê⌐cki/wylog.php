<?php
session_start();
session_destroy();
//Powrót do strony logowania
header('Location: home.php');
?>