<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Logowanie</title>
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
		<link href="styl.css" rel="stylesheet" type="text/css">
	</head>
	<body class="loggedin">
		<div class="login">
			<h1>Logowanie</h1>
			<form method="post">
				<label for="username">
					<i class="fas fa-user"></i>
				</label>
				<input type="text" name="nick" placeholder="Podaj nazwę użytkownika" id="nick" required>
				<label for="password">
					<i class="fas fa-lock"></i>
				</label>
				<input type="password" name="haslo" placeholder="Podaj hasło" id="haslo" required>
				Nie masz konta?<a href="rejestracja.php">Zarejestruj się</a>
				<input type="submit" value="Zaloguj się">
			</form>
		</div>
	</body>
</html>

<?php
function logow(){
session_start();
    $con = mysqli_connect('localhost','root','','forum2');
if ( mysqli_connect_errno() ) {
	exit("<p style='color:white;text-align:center;'>Nie udało połączyć się z bazą danych: " . mysqli_connect_error()."</p>");
}
// Sprawdzenie czy pola są puste
if ( !isset($_POST['nick'], $_POST['haslo']) ) {
	exit("<p style='color:white;text-align:center;'>Proszę wypełnić cały formularz!</p>");
}
//Wyszukanie użytkownika po jego nazwie w bazie danych
if ($stmt = $con->prepare('SELECT id, haslo FROM konta WHERE nick = ?')) {
	$stmt->bind_param('s', $_POST['nick']);
	$stmt->execute();
	$stmt->store_result();
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $password);
        $stmt->fetch();
        // Konto istnieje -> weryfikacja hasła
        if (password_verify($_POST['haslo'], $password)) {
            // Utworzenie sesji z logowaniem
            session_regenerate_id();
            $_SESSION['loggedin'] = TRUE;
            $_SESSION['name'] = $_POST['nick'];
            $_SESSION['id'] = $id;
            header('Location: home.php');
        } else {
            echo "<p style='color:white;text-align:center;'>Nie poprawna nazwa użytkownika lub hasło!</p>";
        }
    } else {
        echo "<p style='color:white;text-align:center;'>Nie poprawna nazwa użytkownika lub hasło!</p>";
    }
	$stmt->close();
}
}
	//Sprawdzenie czy formularz jest pusty, jeśli nie uruchomienie funkcji logowania
	if (!empty($_POST['nick']) || !empty($_POST['haslo'])){
		logow();
	}else{
		echo "<p style='color:white;text-align:center;'>Prosze wypełnić formularz</p>";
	}
?>