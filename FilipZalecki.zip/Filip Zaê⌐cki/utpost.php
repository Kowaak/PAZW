<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.php');
	exit;
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Utwórz posta</title>
		<link href="styl.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
	<body class="loggedin">
		<nav class="navtop">
			<div>
				<h1>Forum</h1>
				<a href="baza.sql" download><i class="fas fa-file"></i>BazaSQL</a>
				<a href="dokumentacja.php"><i class="fas fa-book"></i>Dokumentacja</a>
				<a href="profile.php"><i class="fas fa-user-circle"></i><?=$_SESSION['name']?></a>
				<a href="home.php"><i class="fas fa-sign-out-alt"></i>Powrót</a>
			</div>
		</nav>
		<div class="utpost">
            <form method="post">
            <input name="tytul" type="text"  maxlength="50" placeholder="Tytuł posta"><br>
            <textarea name="tresc" style="height:100px;width:1000px;"  maxlength="200" placeholder="Treść"></textarea>
            <input type="submit" value="Utwórz post">
            </form>
			<?php
            function utpost(){
			//Zebranie danych z formularza
            $ty = $_POST['tytul'];
            $tr = $_POST['tresc'];
            $id = $_SESSION['id'];
            $db = mysqli_connect('localhost','root','','forum2');
			//Utworzenie wpisu/postu w bazie danych
			$wynik = mysqli_query($db, "INSERT INTO post (id_postu,tytul,tresc,id_uzytkownika) VALUES ('NULL','$ty','$tr','$id')");
            header('Location: home.php');
            }
			 //Sprawdzenie czy formularz jest pusty, jeśli nie uruchomienie funkcji logowania
            if(!empty($_POST['tytul'])&&!empty($_POST['tresc'])){
                utpost();
            }
			?>
		</div>
	</body>
</html>