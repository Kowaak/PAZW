<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.php');
	exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="styl.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <title>Post</title>
</head>
<body class="loggedin">
        <nav class="navtop">
			<div>
				<h1>Forum</h1>
                <?php
                $idpostu = $_GET['id'];
                echo "<a href='utkom.php?id=$idpostu'><i class='fas fa-newspaper'></i>Utwórz komentarz</a>";
                ?>
				<a href="baza.sql" download><i class="fas fa-file"></i>BazaSQL</a>
				<a href="dokumentacja.php"><i class="fas fa-book"></i>Dokumentacja</a>
				<a href="profile.php"><i class="fas fa-user-circle"></i><?=$_SESSION['name']?></a>
				<a href="home.php"><i class="fas fa-sign-out-alt"></i>Powrót</a>
			</div>
		</nav>
        <div class="content">
    <?php
        $db = mysqli_connect('localhost','root','','forum2');
        $wynik = mysqli_query($db, "SELECT id_uzytkownika,tytul,tresc FROM post WHERE id_postu = $idpostu;");
        $wiersz = mysqli_fetch_all($wynik, MYSQLI_ASSOC);
            foreach($wiersz as $x){
            echo "<article><h1>{$x['tytul']}<h1>";
            echo "<h3>{$x['tresc']}<h3>
            Autor:{$x['id_uzytkownika']}</article>";
            }
        $wynik = mysqli_query($db, "SELECT tresc,id_us FROM kome WHERE id_post = $idpostu;");
        $wiersz = mysqli_fetch_all($wynik, MYSQLI_ASSOC);
            foreach($wiersz as $x){
                echo "<article><h3><br>{$x['tresc']}<h3>
                Autor:{$x['id_us']}</article>";
            }
    ?>
    </div>
</body>
</html>