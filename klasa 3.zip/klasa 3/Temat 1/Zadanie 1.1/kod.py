def szukaj(tekst,wzorzec):
    dlT, dlW = len(tekst), len(wzorzec)
    if dlW > dlT:
        return False
    n=0
    for i in range(dlT - dlW + 1):
        for j in range(i, i + dlW):
            if tekst[j] != wzorzec[j - i]:
                break
        if j + 1 == i + dlW:
            n += 1
    return n
    
print(szukaj('INFORMATOR','OR'))
print(szukaj('INTERNET','OR'))
