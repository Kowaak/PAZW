# a)
tekst = input("Podaj tekst: ")
print("Liczba znaków 'z' w napisie: ", tekst.count('z'))

# b)
tekst = input("\nPodaj tekst: ")
print("Łączna liczba znaków 'm' i 'n' w napisie: ", tekst.count('m')+tekst.count('n'))

# c)
tekst = input("\nPodaj tekst: ")
slowo = input("Podaj szukane słowo:")
print("Pozycja pierwszego wystąpienia w napisie slowa: ",slowo," = ", tekst.find(slowo))

# d)
tekst = input("\nPodaj tekst: ")
print("Pozycja pierwszego wystąpenia w napisie slowa 'ab' = ", tekst.rfind('ab'))
