def szukaj(tekst,wzorzec):
    dlT, dlW = len(tekst), len(wzorzec)
    T = []
    if dlW > dlT:
        return "Tekst nie zawiera wzorca"
    for i in range(dlT - dlW + 1):
        for j in range(i,i + dlW):
            if tekst[j] != wzorzec[j - i]:
                break
        if j + 1 == i + dlW:
            T.append(i)
    if T == []:
        return "Tekst nie zawiera wzorca"
    return T[len(T) - 1]

print(szukaj('TO JEST NAPIS, TAM TEZ JEST NAPIS','SPIS'))
print(szukaj('TO JEST SPIS, TAM TEZ JEST SPIS','SPIS'))
