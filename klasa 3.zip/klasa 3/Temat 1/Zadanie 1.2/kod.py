def szukaj(tekst,wzorzec):
    dlT, dlW = len(tekst), len(wzorzec)
    T = []
    if dlW > dlT:
        return "Tekst nie zawiera wzorca"
    for i in range(dlT - dlW + 1):
        for j in range(i, i + dlW):
            if tekst[j] != wzorzec[j - i]:
                break
        if j + 1 == i + dlW:
            return i
    return "Tekst nie zawiera wzorca"
    
print(szukaj('TO JEST NAPIS, TAM TEŻ JEST NAPIS','NAPIS'))
print(szukaj('TO JEST SPIS, TAM TEŻ JEST SPIS','NAPIS'))
