def szukaj(T, n):
    i = 0
    while i < n and T[i] == -1:
        i += 1
    pom = i
    if pom < n - 1:
        for j in range(i + 1, n):
            if T[j] != -1 and T[j] < T[pom]:
                pom = j
    return pom

def polacz(T, n):
    koszt = 0
    i = 0
    while i < n - 1:
        suma = 0
        min_1 = szukaj(T, n)
        if min_1 < n:
            suma += T[min_1]
            T[min_1] = -1
            min_2 = szukaj(T, n)
        if min_2 < n:
            suma += T[min_2]
            T[min_2] = suma
            koszt += suma
        i += 1
    return koszt

T = []
n = int(input("podaj liczbę wyrazów ciagu: "))
print("podaj wyrazy ciągu liczbowego:")
for i in range(n):
    T.append(int(input()))
print("całkowity minimalny koszt połączenia =", polacz(T, n))
