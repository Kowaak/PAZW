K = [500, 200, 100, 50, 20, 10] 
LICZBY = [0,0,0,0,0,0] 
WYPLATY = []
n = int(input("podaj liczbę pracowników: ")) 
print("Dodaj wypłaty pracowników:") 
for i in range(n):
    WYPLATY.append(int (input()))
for i in range (n) :
    reszta = WYPLATY[i]
    for j in range (6):
        LICZBY[j] += reszta // K[j]
        reszta %= K[j]
print("liczba banknotów:")
for j in range (6):
    print (K[j],"zł =", LICZBY [j], "szt.")