reszta = int(input("podaj reszte do wydania (w groszach): "))
T = [50000,20000,10000,5000,2000,1000,500,200,100,50,20,10,5,2,1]
K = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
i = 0
while reszta > 0:
    K[i] = reszta // T[i]
    reszta %= T[i]
    i+= 1
for i in range(15):
    print(T[i], ' =', K[i])