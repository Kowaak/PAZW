W = [125, 150, 160, 158, 170, 160, 172, 179, 180]
C = [27, 47, 52, 52, 64, 64, 78, 92, 102]
L = [4, 3, 2, 1, 2, 3, 4, 4, 2]
K = []
waga_max = waga = 900
n = 9
wynik = 0
waga_osob = 0

for i in range(n):
    pom = waga // C[i]
    if pom >= L[i]:
        K.append(L[i])
    else:
        K.append(pom)
    L[i] -= K[i]
    waga -= K[i] * C[i]
    waga_osob += K[i] * C[i]
    wynik += W[i] * K[i]

print("maksymalne obciążenie windy =", waga_max)
print("całkowita suma wysokości osób wchodzących do windy =", wynik)
print("całkowita waga osób wchodzących do windy =", waga_osob)
print("osoby, które powinny wejść do windy:")
for i in range(n):
    print("wzrost =", W[i], "waga =", C[i], "ilość =", K[i], "pozostało =", L[i])
    