def szukaj(T, n):
    i = 0
    while T[i] == -1 and i < n:
        i += 1
    pom = i
    if pom < n - 1:
        for j in range(i + 1, n):
            if T[j] != -1 and T[j] > T[pom]:
                pom = j
    return pom

def polacz(T, n):
    koszt = 0
    i = 0
    while i < n - 1:
        suma = 0
        max_1 = szukaj(T, n) 
        if max_1 < n:
            suma += T[max_1]
            T[max_1] = -1
            max_2 = szukaj(T, n) 
        if max_2 < n:
            suma += T[max_2]
            T[max_2] = suma
            koszt += suma
        i += 1
    return koszt

T = []
n = int(input("podaj liczbę wyrazów ciągu: "))
print("podaj wyrazy ciągu liczbowego:")
for i in range(n):
    T.append(int(input()))
print("całkowity maksymalny koszt połączenia =", polacz(T, n))